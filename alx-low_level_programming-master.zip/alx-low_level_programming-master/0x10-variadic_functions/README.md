Solutions to tasks on variadic functions

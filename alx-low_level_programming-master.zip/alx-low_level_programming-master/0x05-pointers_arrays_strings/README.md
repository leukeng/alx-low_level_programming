pointers and arrays

0x0C. C - More malloc, free projects taks with ALX with vi technology used as editor

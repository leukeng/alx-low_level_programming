Solution to tasks on doubly linked list

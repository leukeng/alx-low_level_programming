#include <stdio.h>
/**
 * main - Entry point
 * Description: base 10 in string
 * Return: 0
 */
int main(void)
{	int a;
	for (a = '0'; a <= '9'; a++)
	{ putchar(a); }
	putchar('\n');
	return (0);
}

#include <stdio.h>

/**
 * main - Entry point
 * Description: all alphabet except e and a
 * Return: 0
 */

int main(void)
{	char low;
	for (low = 'a'; low <= 'z'; low++)
	{
		if (low != 'e' && low != 'q')
		putchar(low);
	}
	putchar('\n');
	return (0);
}

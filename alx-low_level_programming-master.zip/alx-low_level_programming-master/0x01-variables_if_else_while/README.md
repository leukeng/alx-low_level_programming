Positive anything is better than negative nothing

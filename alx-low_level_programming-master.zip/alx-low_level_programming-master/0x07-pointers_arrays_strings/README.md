This folder contains solutions to 0x07. C - Even more pointers, arrays and strings

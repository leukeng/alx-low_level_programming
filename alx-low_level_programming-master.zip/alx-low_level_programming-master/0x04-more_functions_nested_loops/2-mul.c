#include "main.h"

/**
 *mul - multiplies two numbers
 *@a: first number
 *@b: second number
 *Return: returns result
 */

int mul(int a, int b)
{
	return (a * b);
}

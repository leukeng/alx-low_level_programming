more functions nested loops project

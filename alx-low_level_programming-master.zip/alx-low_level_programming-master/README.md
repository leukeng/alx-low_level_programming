showing the code related to task

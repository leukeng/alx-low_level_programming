void _puts_recursion(char *s);
int _putchar(char c);
int _strlen_recursion(char *s);

Functions and Nested loop project

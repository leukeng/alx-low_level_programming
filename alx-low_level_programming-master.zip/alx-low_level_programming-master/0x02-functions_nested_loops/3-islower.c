#include "main.h"

/**
 * _islower - print 1 or 0 depending on input
 * @c: first parameter
 * Description: lower letter only
 * Return: 0
 */

int _islower(int c)
{
	return (c >= 'a' && c <= 'z');
}

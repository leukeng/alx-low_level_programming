malloc_free
with updated task 101

#ifndef FILE_HOLBERTON
#define FILE_HOLBERTON

int _putchar(char c);

#endif

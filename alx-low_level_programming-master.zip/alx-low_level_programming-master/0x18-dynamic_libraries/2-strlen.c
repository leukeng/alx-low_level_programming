#include "main.h"
#include <string.h>

/**
* _strlen -> a function that get the length of a string
* @s: string pointer to passed to this function
* Return: this returns length of the string
*/
int _strlen(char *s)
{
	return (strlen(s));
}

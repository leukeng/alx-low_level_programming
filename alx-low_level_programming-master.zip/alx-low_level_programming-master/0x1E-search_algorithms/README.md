# Solutions to tasks on 0x1E. C - Search Algorithms

0 – Write a script that runs a C file through the preprocessor and save the result into another file

1 – Write a script that generate the assembly code of a C code and save it in an output file.

2 – Write a script that compiles a C file but does not link.

3 – Write a script that compiles a C file and create an executable named cisfun.

4 – Write a C program that prints exactly “programming is like building a multilingual puzzle, followed by a new line.

5 – Write a c program that prints exactly with proper gramer, but the outcome is a piece of art, followed by a new line.

6 – Write a C program that prints the size of various types on the computer it is compiled and run on.

7 – (100 – Intel) Write a script that generate the assembly code (Intel syntax) of a C code and save it in an output file.

